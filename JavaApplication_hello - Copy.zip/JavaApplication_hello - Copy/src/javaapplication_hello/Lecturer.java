/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication_hello;

/**
 *
 * @author sumapan
 */
public class Lecturer extends Person {
    private String nidn;
    private String expertise;

    public Lecturer(String idCard, String name,
                    String nidn, String expertise) {
        super(idCard, name);
        this.nidn = nidn;
        this.expertise = expertise;
    }

    public Lecturer(String idCard, String name) {
        super(idCard, name);
        this.nidn = "-";
        this.expertise = "-";
    }

    public String getNidn() {
        return nidn;
    }

    public void setNidn(String nidn) {
        this.nidn = nidn;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }
}