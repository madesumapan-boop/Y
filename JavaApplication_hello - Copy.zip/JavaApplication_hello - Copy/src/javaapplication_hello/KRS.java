/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication_hello;

/**
 *
 * @author sumapan
 */
public class KRS {
    private Course course;
    private double score;
    private String grade;

    public KRS(Course course, double score) {
        this.course = course;
        this.score = score;
        setGrade();
    }

    public Course getCourse() {
        return course;
    }

    public double getScore() {
        return score;
    }

    public String getGrade() {
        return grade;
    }

    private void setGrade() {
        if (score >= 85) {
            grade = "A";
        } else if (score >= 70) {
            grade = "B";
        } else if (score >= 60) {
            grade = "C";
        } else if (score >= 50) {
            grade = "D";
        } else {
            grade = "E";
        }
    }
@Override
public String toString() {
    return course.getName() + " - " + grade;
    }
}
    
