/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication_hello;

/**
 *
 * @author sumapan
 */
public class Course {
    private String code;
    private String name;
    private int sks;
    private int semester;
    private Lecturer lecturer; 

    public Course(String code, String name, int sks, int semester, Lecturer lecturer) {
        this.code = code;
        this.name = name;
        this.sks = sks;
        this.semester = semester;
        this.lecturer = lecturer;
    }

    public String getCode() {
        return code;
    }
    
    public String getKode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSKS() {
        return sks;
    }

    public void setSks(int sks) {
        this.sks = sks;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    
    public Lecturer getLecturer() {
        return lecturer;
    }

    public void setLecturer(Lecturer lecturer) {
        this.lecturer = lecturer;
    }

    @Override
    public String toString() {
        return name;
    }
}